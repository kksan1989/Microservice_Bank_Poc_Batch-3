package com.bank.cardsservice;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name = "Cards")
@Entity
public class Cards {

	private static final long serialVersionUID = 1L;
	@Id // Pk
	@Column(name = "CARDSID")
	Integer cardsId;

	@Column(name = "CARDSNAME")
	String cardsName;

	@Column(name = "CARDSTYPE")
	String cardsType;

	@Column(name = "CARDSNUMBER")
	int cardsNumber;

	@Column(name = "EPIRYDATE")
	String expiryDate;

	@Column(name = "BANK")
	String bank;

	public Cards() {
	}

	public Cards(Integer cardsId, String cardsName, String cardsType, int cardsNumber, String expiryDate, String bank) {
		super();
		this.cardsId = cardsId;
		this.cardsName = cardsName;
		this.cardsType = cardsType;
		this.cardsNumber = cardsNumber;
		this.expiryDate = expiryDate;
		this.bank = bank;
	}

	public Integer getCardsId() {
		return cardsId;
	}

	public void setCardsId(Integer cardsId) {
		this.cardsId = cardsId;
	}

	public String getCardsName() {
		return cardsName;
	}

	public void setCardsName(String cardsName) {
		this.cardsName = cardsName;
	}

	public String getCardsType() {
		return cardsType;
	}

	public void setCardsType(String cardsType) {
		this.cardsType = cardsType;
	}

	public int getCardsNumber() {
		return cardsNumber;
	}

	public void setCardsNumber(int cardsNumber) {
		this.cardsNumber = cardsNumber;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getBank() {
		return bank;
	}

	public void setBank(String bank) {
		this.bank = bank;
	}

	@Override
	public String toString() {
		return "Cards [cardsId=" + cardsId + ", cardsName=" + cardsName + ", cardsType=" + cardsType + ", cardsNumber="
				+ cardsNumber + ", expiryDate=" + expiryDate + ", bank=" + bank + "]";
	}


}
