package com.bank.cardsservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
public class CardsController {

    @Autowired
    private CardsRepository cardsRepository;

    @PostMapping(value = "/cards")
    public Cards save (@RequestBody Cards cards){
        return cardsRepository.save(cards);
    }

    @GetMapping(value = "/cards")
    public Iterable<Cards> all (){
        return cardsRepository.findAll();
    }

    @GetMapping(value = "/cards/{cardsId}")
    public Cards findByAccountId (@PathVariable Integer cardsId){
        return cardsRepository.findCardsByCardsId(cardsId);
    }

    @PutMapping(value = "/cards")
    public Cards update (@RequestBody Cards cards){
        return cardsRepository.save(cards);
    }

    @DeleteMapping(value = "/cards")
    public void delete (@RequestBody Cards cards){
        cardsRepository.delete(cards);
    }

    @GetMapping(value = "/cards/cards-type/{type}")
    public List<Cards> findByemployeeType (@PathVariable String type){
	return cardsRepository.findAllByCardsType(type);
    }
	
    @GetMapping(value = "/cards/bank/{bank}")
    public List<Cards> findByBank (@PathVariable String bank){
	return cardsRepository.findByBank(bank);
    }
	
    @GetMapping(value = "/cards/customer/{customer}")
    public List<Cards> findByCutomer (@PathVariable Integer customer){
	return cardsRepository.findAllByCustomerId(customer);
    }

}
