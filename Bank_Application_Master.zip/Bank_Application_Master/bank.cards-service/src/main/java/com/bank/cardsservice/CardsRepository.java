package com.bank.cardsservice;

import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface CardsRepository extends CrudRepository<Cards, Integer> {

    List<Cards> findAllByCustomerId(Integer customerId);

    List<Cards> findAllByCardsType(String accountType);

    List<Cards> findByBank(String bank);

    Cards findCardsByCardsId(Integer accountId);

}
