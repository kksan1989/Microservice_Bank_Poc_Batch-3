package com.bank.corporateservice;

import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface CoporateRepository extends CrudRepository<Corporate, Integer> {

    List<Corporate> findAllByCustomerId(Integer customerId);

    List<Corporate> findAllByCorporateType(String accountType);

    List<Corporate> findByBank(String bank);

	Corporate findCorporateByCorporateId(Integer corId);

}
