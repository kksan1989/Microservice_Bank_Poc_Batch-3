package com.bank.businessservice;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name = "BUSINESS")
@Entity
public class Business {

	private static final long serialVersionUID = 1L;
	@Id // Pk
	@Column(name = "BUSINESSID")
	Integer businessId;

	@Column(name = "BUSINESSNAME")
	String businessName;

	@Column(name = "ADDRESS")
	String address;

	@Column(name = "MOBILENO")
	int mobileNo;

	@Column(name = "EMAIL")
	String emailAddress;

	@Column(name = "BANK")
	String bank;

	public Business() {
	}

	public Integer getBusinessId() {
		return businessId;
	}

	public void setBusinessId(Integer businessId) {
		this.businessId = businessId;
	}

	public String getBusinessName() {
		return businessName;
	}

	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getBank() {
		return bank;
	}

	public void setBank(String bank) {
		this.bank = bank;
	}

	@Override
	public String toString() {
		return "Business [businessId=" + businessId + ", businessName=" + businessName + ", address=" + address
				+ ", mobileNo=" + mobileNo + ", emailAddress=" + emailAddress + ", bank=" + bank + "]";
	}

}
