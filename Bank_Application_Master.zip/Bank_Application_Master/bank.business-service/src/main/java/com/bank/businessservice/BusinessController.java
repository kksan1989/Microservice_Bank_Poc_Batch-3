package com.bank.businessservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
public class BusinessController {

    @Autowired
    private BusinessRepository businessRepository;

    @PostMapping(value = "/employee")
    public Business save (@RequestBody Business business){
        return businessRepository.save(business);
    }

    @GetMapping(value = "/business")
    public Iterable<Business> all (){
        return businessRepository.findAll();
    }

    @GetMapping(value = "/business/{empId}")
    public Business findByAccountId (@PathVariable Integer businessId){
        return businessRepository.findByBusinessId(businessId);
    }

    @PutMapping(value = "/business")
    public Business update (@RequestBody Business business){
        return businessRepository.save(business);
    }

    @DeleteMapping(value = "/business")
    public void delete (@RequestBody Business business){
    	businessRepository.delete(business);
    }

    @GetMapping(value = "/business/business-type/{type}")
    public List<Business> findByemployeeType (@PathVariable String type){
	return businessRepository.findAllByBusinessType(type);
    }
	
    @GetMapping(value = "/business/bank/{bank}")
    public List<Business> findByBank (@PathVariable String bank){
	return businessRepository.findByBank(bank);
    }
	
    @GetMapping(value = "/business/customer/{businessid}")
    public List<Business> findByCutomer (@PathVariable Integer businessid){
	return businessRepository.findAllByBusinessId(businessid);
    }

}
