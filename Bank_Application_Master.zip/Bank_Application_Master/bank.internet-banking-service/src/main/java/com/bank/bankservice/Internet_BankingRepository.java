package com.bank.bankservice;

import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface Internet_BankingRepository extends CrudRepository<Internet_Banking, Integer> {

    Internet_Banking findBankByBankingId(Integer customerId);

    List<Internet_Banking> findAllByBankingType(String accountType);

    List<Internet_Banking> findByBank(String bank);

    List<Internet_Banking> findAllByBankingId(Integer accountId);

}
