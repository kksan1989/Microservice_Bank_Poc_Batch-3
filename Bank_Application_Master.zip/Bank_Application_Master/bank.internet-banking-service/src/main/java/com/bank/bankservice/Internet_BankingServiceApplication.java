package com.bank.bankservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient
public class Internet_BankingServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(Internet_BankingServiceApplication.class, args);
	}

}
