package com.bank.bankservice;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name = "INTERNETBANKING")
@Entity
public class Internet_Banking {

	private static final long serialVersionUID = 1L;
	@Id // Pk
	@Column(name = "INTERNETBANKID")
	Integer internetBankId;

	@Column(name = "ADDRESS")
	String address;

	@Column(name = "ACCOUNTNUMBER")
	int accountNumber;

	@Column(name = "BALANCE")
	double balance;

	@Column(name = "BANK")
	String bank;

	public Internet_Banking() {
	}

	public Internet_Banking(Integer internetBankId, String address, int accountNumber, double balance, String bank) {
		super();
		this.internetBankId = internetBankId;
		this.address = address;
		this.accountNumber = accountNumber;
		this.balance = balance;
		this.bank = bank;
	}

	public Integer getInternetBankId() {
		return internetBankId;
	}

	public void setInternetBankId(Integer internetBankId) {
		this.internetBankId = internetBankId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getBank() {
		return bank;
	}

	public void setBank(String bank) {
		this.bank = bank;
	}

	@Override
	public String toString() {
		return "Internet_Banking [internetBankId=" + internetBankId + ", address=" + address + ", accountNumber="
				+ accountNumber + ", balance=" + balance + ", bank=" + bank + "]";
	}

	
	
}
