package com.bank.productservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
public class ProductController {

    @Autowired
    private ProductRepository productRepository;

    @PostMapping(value = "/product")
    public Product save (@RequestBody Product product){
        return productRepository.save(product);
    }

    @GetMapping(value = "/product")
    public Iterable<Product> all (){
        return productRepository.findAll();
    }

    @GetMapping(value = "/product/{productId}")
    public Product findByAccountId (@PathVariable Integer productId){
        return productRepository.findAllByProductId(productId);
    }

    @PutMapping(value = "/product")
    public Product update (@RequestBody Product product){
        return productRepository.save(product);
    }

    @DeleteMapping(value = "/product")
    public void delete (@RequestBody Product product){
        productRepository.delete(product);
    }

    @GetMapping(value = "/product/product-type/{type}")
    public List<Product> findByemployeeType (@PathVariable String type){
	return productRepository.findAllByProductType(type);
    }
	
    @GetMapping(value = "/product/bank/{bank}")
    public List<Product> findByBank (@PathVariable String bank){
	return productRepository.findByBank(bank);
    }
	
    @GetMapping(value = "/product/customer/{customer}")
    public Product findByCutomer (@PathVariable Integer customer){
	return productRepository.findProductByProductId(customer);
    }

}
