package com.bank.productservice;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name = "STUDENT")
@Entity
public class Product {

	private static final long serialVersionUID = 1L;
	@Id // Pk
	@Column(name = "STUDID")
	Integer studId;

	@Column(name = "STUDNAME")
	Double studName;

	@Column(name = "ADDRESS")
	Integer address;

	@Column(name = "MOBILENO")
	String mobileNo;

	@Column(name = "EMAIL")
	String emailAddress;

	@Column(name = "BANK")
	String bank;

	public Product() {
	}

	public Product(Integer studId, Double studName, Integer address, String mobileNo, String emailAddress,
			String bank) {
		super();
		this.studId = studId;
		this.studName = studName;
		this.address = address;
		this.mobileNo = mobileNo;
		this.emailAddress = emailAddress;
		this.bank = bank;
	}
	

	public Integer getStudId() {
		return studId;
	}

	public void setStudId(Integer studId) {
		this.studId = studId;
	}

	public Double getStudName() {
		return studName;
	}

	public void setStudName(Double studName) {
		this.studName = studName;
	}

	public Integer getAddress() {
		return address;
	}

	public void setAddress(Integer address) {
		this.address = address;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getBank() {
		return bank;
	}

	public void setBank(String bank) {
		this.bank = bank;
	}

	@Override
	public String toString() {
		return "Student [studId=" + studId + ", studName=" + studName + ", address=" + address + ", mobileNo="
				+ mobileNo + ", emailAddress=" + emailAddress + ", bank=" + bank + "]";
	}

	
}
