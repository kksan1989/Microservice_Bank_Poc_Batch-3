package com.bank.loanservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
public class LoanController {

    @Autowired
    private LoanRepository loanRepository;

    @PostMapping(value = "/laon")
    public Loan save (@RequestBody Loan loan){
        return loanRepository.save(loan);
    }

    @GetMapping(value = "/loan")
    public Iterable<Loan> all (){
        return loanRepository.findAll();
    }

    @GetMapping(value = "/loan{loanId}")
    public Loan findByAccountId (@PathVariable Integer loanId){
        return loanRepository.findLoanByLoanId(loanId);
    }

    @PutMapping(value = "/loan")
    public Loan update (@RequestBody Loan loan){
        return loanRepository.save(loan);
    }

    @DeleteMapping(value = "/loan")
    public void delete (@RequestBody Loan loan){
        loanRepository.delete(loan);
    }

    @GetMapping(value = "/employee/employee-type/{type}")
    public List<Loan> findByemployeeType (@PathVariable String type){
	return loanRepository.findAllByLoanType(type);
    }
	
    @GetMapping(value = "/account/bank/{bank}")
    public List<Loan> findByBank (@PathVariable String bank){
	return loanRepository.findByBank(bank);
    }
	
    @GetMapping(value = "/account/customer/{customer}")
    public Loan findByCutomer (@PathVariable Integer customer){
	return loanRepository.findAllByLoanId(customer);
    }

}
