package com.bank.savingservice;

import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface SavingRepository extends CrudRepository<Saving, Integer> {

    List<Saving> findAllBySavingId(Integer savingId);

    List<Saving> findAllBySavingType(String savingType);

    List<Saving> findByBank(String bank);

    Saving findsSavingByAccountId(Integer accountId);

}
