package com.bank.savingservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
public class SavingController {

    @Autowired
    private SavingRepository savingRepository;

    @PostMapping(value = "/saving")
    public Saving save (@RequestBody Saving saving){
        return savingRepository.save(saving);
    }

    @GetMapping(value = "/saving")
    public Iterable<Saving> all (){
        return savingRepository.findAll();
    }

    @GetMapping(value = "/saving/{savingId}")
    public Saving findBySavingId (@PathVariable Integer accountId){
        return savingRepository.findsSavingByAccountId(accountId);
    }

    @PutMapping(value = "/saving")
    public Saving update (@RequestBody Saving saving){
        return savingRepository.save(saving);
    }

    @DeleteMapping(value = "/employee")
    public void delete (@RequestBody Saving saving){
        savingRepository.delete(saving);
    }

    @GetMapping(value = "/saivng/saving-type/{type}")
    public List<Saving> findBySavingType (@PathVariable String type){
	return savingRepository.findAllBySavingType(type);
    }
	
    @GetMapping(value = "/saving/bank/{bank}")
    public List<Saving> findByBank (@PathVariable String bank){
	return savingRepository.findByBank(bank);
    }
	
    @GetMapping(value = "/account/customer/{customer}")
    public List<Saving> findByCutomer (@PathVariable Integer savingid){
	return savingRepository.findAllBySavingId(savingid);
    }

}
