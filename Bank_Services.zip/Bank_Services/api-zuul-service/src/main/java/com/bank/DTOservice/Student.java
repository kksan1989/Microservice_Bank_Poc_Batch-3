package com.bank.DTOservice;

public class Student {

	private static final long serialVersionUID = 1L;
	Integer studId;

	String studName;

	String address;

	int mobileNo;

	String emailAddress;

	String bank;

	public Student() {
	}

	public Integer getStudId() {
		return studId;
	}

	public void setStudId(Integer studId) {
		this.studId = studId;
	}

	public String getStudName() {
		return studName;
	}

	public void setStudName(String studName) {
		this.studName = studName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getBank() {
		return bank;
	}

	public void setBank(String bank) {
		this.bank = bank;
	}

	@Override
	public String toString() {
		return "Student [studId=" + studId + ", studName=" + studName + ", address=" + address + ", mobileNo="
				+ mobileNo + ", emailAddress=" + emailAddress + ", bank=" + bank + "]";
	}


	
}
