package com.bank.DTOservice;

public class Corporate {

	private static final long serialVersionUID = 1L;
	int corporateId;

	String corporateName;
	
	String corporateType;

	String address;


	String emailAddress;

	String bank;

	public Corporate() {
	}

	public Corporate(int corporateId, String corporateName, String address, String emailAddress, String bank) {
		super();
		this.corporateId = corporateId;
		this.corporateName = corporateName;
		this.address = address;
		this.emailAddress = emailAddress;
		this.bank = bank;
	}

	public int getCorporateId() {
		return corporateId;
	}

	public void setCorporateId(int corporateId) {
		this.corporateId = corporateId;
	}

	public String getCorporateName() {
		return corporateName;
	}

	public void setCorporateName(String corporateName) {
		this.corporateName = corporateName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getBank() {
		return bank;
	}

	public void setBank(String bank) {
		this.bank = bank;
	}

	public String getCorporateType() {
		return corporateType;
	}

	public void setCorporateType(String corporateType) {
		this.corporateType = corporateType;
	}

	@Override
	public String toString() {
		return "Corporate [corporateId=" + corporateId + ", corporateName=" + corporateName + ", corporateType="
				+ corporateType + ", address=" + address + ", emailAddress=" + emailAddress + ", bank=" + bank + "]";
	}
	
}
